//
//  JSONParser.h
//  Blotter
//
//  Created by Jeff on 2/22/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JSONParser : NSObject

+ (JSONParser*) instance;

@property (nonatomic,retain) NSArray* loadedIncidents;

@end
