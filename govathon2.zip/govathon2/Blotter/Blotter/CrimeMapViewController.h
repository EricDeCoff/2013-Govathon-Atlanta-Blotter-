//
//  CrimeMapViewController.h
//  Blotter
//
//  Created by John McSwain on 2/23/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
@interface CrimeMapViewController : UIViewController <CLLocationManagerDelegate,MKMapViewDelegate>
{
    IBOutlet MKMapView *mapView;
    CLLocationManager *locationManager;
}
@end
