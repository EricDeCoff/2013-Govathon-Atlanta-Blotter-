//
//  Annotation.h
//  Blotter
//
//  Created by John McSwain on 2/23/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
@interface Annotation : NSObject <MKAnnotation>{

NSString *_title;
NSString *_subtitle;

CLLocationCoordinate2D coordinate;
}

// Getters and setters
- (void)setTitle:(NSString *)title;
- (void)setSubtitle:(NSString *)subtitle;
@end
