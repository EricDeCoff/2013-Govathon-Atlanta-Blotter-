//
//  AppDelegate.h
//  Blotter
//
//  Created by John McSwain on 2/22/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SplashViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UITabBarController *tabBarController;
@property (strong, nonatomic) SplashViewController *splashViewController;
@property (strong, nonatomic) UIImageView *navImage;
@end
