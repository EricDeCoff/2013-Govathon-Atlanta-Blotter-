//
//  CrimeMapViewController.m
//  Blotter
//
//  Created by John McSwain on 2/23/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import "CrimeMapViewController.h"
#import "Annotation.h"
#import "JSONParser.h"
#import "Incident.h"

@interface CrimeMapViewController ()

@property (nonatomic,assign) BOOL viewCenteredYet;
@property (nonatomic,retain) UIToolbar* toolbar;
@property (nonatomic,retain) UISegmentedControl* crimeTypeSegmentedControl;
@property (nonatomic,assign) int selectedCrimeInt;
@property (nonatomic,retain) NSMutableArray* crimeArray;
@property (nonatomic,retain) NSArray* segmentedControlValues;

@end

@implementation CrimeMapViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Crime Radar", @"Radar");
        self.tabBarItem.image = [UIImage imageNamed:@"73-radar.png"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    locationManager = [[CLLocationManager alloc]init];
    locationManager.delegate = self;
    mapView.delegate = self;
    [locationManager startUpdatingLocation];

//    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(33.74307,
//                                                                   -84.43767);
//
//    
//    Annotation* pinAnnotation =[[Annotation alloc] init ];
//    pinAnnotation.title = @"Incident Example";
//    pinAnnotation.coordinate = coordinate;
//    [mapView addAnnotation:pinAnnotation];
    // Do any additional setup after loading the view from its nib.
    
    self.toolbar = [[UIToolbar alloc]init];
    [self.toolbar sizeToFit];
    self.toolbar.barStyle = UIBarStyleBlackTranslucent;
    self.toolbar.frame = CGRectMake(self.view.frame.origin.x,self.view.frame.origin.y,self.view.frame.size.width,self.toolbar.frame.size.height);
    NSArray* segemntedControlItems = @[@"Auto Theft",@"Burglary",@"Robbery",@"Larceny"];
    self.segmentedControlValues = @[@"AUTO THEFT",@"BURGLARY",@"ROBBERY",@"LARCENY"]; //kind bogus way of doing this.  almost 2pm.
    self.crimeTypeSegmentedControl = [[UISegmentedControl alloc]initWithItems:segemntedControlItems];
    self.crimeTypeSegmentedControl.segmentedControlStyle = UISegmentedControlStyleBar;
    self.crimeTypeSegmentedControl.tintColor = [UIColor blackColor];
    self.crimeTypeSegmentedControl.frame = CGRectMake(3,6,312,32);
    [self.crimeTypeSegmentedControl addTarget:self
                                       action:@selector(segmentedControlPicked:)
                             forControlEvents:UIControlEventValueChanged];
    [self.toolbar addSubview:self.crimeTypeSegmentedControl];
    [self.view addSubview:self.toolbar];
    
//    self.crimeTypeSegmentedControl.selectedSegmentIndex = 0;
    [self performSelector:@selector(selectInitialSegment) withObject:nil afterDelay:1.0];

}

- (void) selectInitialSegment
{
    [self.crimeTypeSegmentedControl setSelectedSegmentIndex:0];
    [self segmentedControlPicked:self.crimeTypeSegmentedControl];//hackish way for time
}

- (void) segmentedControlPicked:(UISegmentedControl*) sender
{
    self.selectedCrimeInt = sender.selectedSegmentIndex;
    [self updateCrimes];
    NSLog(@"Selected Segment:%i",self.selectedCrimeInt);
    for (int i=0; i<[sender.subviews count]; i++)
    {
        if ([[sender.subviews objectAtIndex:i] respondsToSelector:@selector(isSelected)] && [[sender.subviews objectAtIndex:i]isSelected])
        {
            [[sender.subviews objectAtIndex:i] setTintColor:[UIColor grayColor]];
        }
        if ([[sender.subviews objectAtIndex:i] respondsToSelector:@selector(isSelected)] && ![[sender.subviews objectAtIndex:i] isSelected])
        {
            [[sender.subviews objectAtIndex:i] setTintColor:[UIColor blackColor]];
        }
    }
}

- (void) updateCrimes
{
    self.crimeArray = [[NSMutableArray alloc]init];
    NSArray* incidents = [[JSONParser instance]loadedIncidents];
    NSString* crimeTypeSelectedString = [self.segmentedControlValues objectAtIndex:self.selectedCrimeInt];
    NSLog(@"crimeTypeSelectedString:%@",crimeTypeSelectedString);
    for(int i=0;i<incidents.count;++i)
    {
        Incident* incident = (Incident*)[incidents objectAtIndex:i];
        
        if([incident.uc2Literal isEqualToString:crimeTypeSelectedString])
        {

            NSLog(@"Adding Crime. %@, %@",incident.uc2Literal,incident.longitude);
            [self.crimeArray addObject:incident];
        }
        
        if(self.crimeArray.count>59)
        {
            NSLog(@"new count incidents:%i",self.crimeArray.count);
            [self updateAnnotations];
            return;
        }
    }
    NSLog(@"new count incidents:%i",self.crimeArray.count);
}

- (void) updateAnnotations
{
    NSLog(@"updateAnnotations");
    [mapView removeAnnotations:mapView.annotations];
    for(int i=0;i<self.crimeArray.count;++i)
    {
        NSLog(@"annotation");
        Incident* incident = [self.crimeArray objectAtIndex:i];
        CLLocationDegrees longitude = [incident.longitude doubleValue];
        NSLog(@"string long:%@",incident.longitude);
        NSLog(@"longitde:%f",longitude);
        CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake([incident.latitude doubleValue], [incident.longitude doubleValue]);
        NSLog(@"coordinate.lat:%f,lng:%f",coordinate.latitude,coordinate.longitude);
        
        Annotation* pinAnnotation =[[Annotation alloc] init ];
        pinAnnotation.title = incident.location;
        pinAnnotation.coordinate = coordinate;
        [mapView addAnnotation:pinAnnotation];
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation{
    if(!self.viewCenteredYet)
    {
        [mapView setCenterCoordinate:manager.location.coordinate animated:NO];
        MKCoordinateSpan span = MKCoordinateSpanMake(.03,.03);
        
        MKCoordinateRegion region = MKCoordinateRegionMake(manager.location.coordinate, span);
        [mapView setRegion:region animated:YES];
        self.viewCenteredYet = YES;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
