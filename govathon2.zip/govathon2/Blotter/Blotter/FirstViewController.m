//
//  FirstViewController.m
//  Blotter
//
//  Created by John McSwain on 2/22/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import "FirstViewController.h"
#import "JSONParser.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"About", @"About");
        self.tabBarItem.image = [UIImage imageNamed:@"first"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self performSelectorInBackground:@selector(loadJSON) withObject:nil];
}

- (void) loadJSON
{
    [JSONParser instance];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
