//
//  SecondViewController.m
//  Blotter
//
//  Created by John McSwain on 2/22/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import "SecondViewController.h"
#import "IncidentReportViewController.h"

@interface SecondViewController ()

@property (retain, nonatomic) IBOutlet UITextField *txtCaseNumber;
@property (nonatomic, retain) UINavigationController* navController;
@property (nonatomic, retain) UIAlertView* emailAlertView;
@property (nonatomic, retain) UIAlertView* emailCompleteAlertView;

@end

@implementation SecondViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Incidents", @"Second");
        self.tabBarItem.image = [UIImage imageNamed:@"shield"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
     _txtCaseNumber.borderStyle = UITextBorderStyleNone;
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_txtCaseNumber release];
    [super dealloc];
}
- (IBAction)goButton_onTouchUpInside:(id)sender {
    NSLog(@"GO! they entered case #: %@",_txtCaseNumber.text);
    UIViewController *incidentReportViewController = [[[IncidentReportViewController alloc] initWithNibName:@"IncidentReportViewController" bundle:nil] autorelease];
    self.navController = [[[UINavigationController alloc] initWithRootViewController:incidentReportViewController] autorelease];
    self.navController.navigationBar.tintColor = [UIColor blackColor];
    [self.navController.navigationBar.topItem setLeftBarButtonItem:
     [[[UIBarButtonItem alloc] initWithTitle: @"Back"
                                       style: UIBarButtonItemStyleDone
                                      target: self
                                     action: @selector(dismissNavController:)]autorelease]];
    [self.navController.navigationBar.topItem setRightBarButtonItem:
     [[[UIBarButtonItem alloc] initWithTitle: @"Email"
                                     style: UIBarButtonItemStylePlain
                                    target: self
                                    action: @selector(emailIncidentReport:)]autorelease]];
    _txtCaseNumber.text = @"";
   
    [_txtCaseNumber resignFirstResponder];
    [self presentModalViewController:self.navController animated:YES];
}

- (void) dismissNavController:(id) sender
{
    [self dismissViewControllerAnimated:self.navController completion:nil];
}

- (void) emailIncidentReport:(id) sender
{
    self.emailAlertView = [[[UIAlertView alloc]initWithTitle:@"Email Incident Report" message:@"Enter an email address to receive your incident report" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil]autorelease];
    self.emailAlertView.alertViewStyle = UIAlertViewStylePlainTextInput;
    [self.emailAlertView show];
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    NSLog(@"DISMISSED");
    if(alertView == self.emailAlertView && buttonIndex == 1)
    {
        self.emailCompleteAlertView = [[[UIAlertView alloc]initWithTitle:@"Success!" message:@"Your incident report has been emailed to the address provided" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil]autorelease];
        [_emailCompleteAlertView show];
    }
    else if(self.emailCompleteAlertView == alertView)
    {
        [_txtCaseNumber resignFirstResponder];
    }
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    NSLog(@"touchesBegan!!");
    UITouch * touch = [touches anyObject];
    if(touch.phase == UITouchPhaseBegan) {
        [self.txtCaseNumber resignFirstResponder];
    }
}


@end
