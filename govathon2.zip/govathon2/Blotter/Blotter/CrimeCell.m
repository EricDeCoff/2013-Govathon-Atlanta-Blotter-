//
//  CrimeCell.m
//  Blotter
//
//  Created by Jeff on 2/23/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import "CrimeCell.h"

@implementation CrimeCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        NSLog(@"I....AM...ALIIIIVE!");
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [_lblCaseNumber release];
    [_lblLocation release];
    [_lblCrimeType release];
    [_lblTime release];
    [super dealloc];
}
@end
