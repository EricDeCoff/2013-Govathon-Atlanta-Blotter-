//
//  Incident.h
//  Blotter
//
//  Created by Jeff on 2/22/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Incident : NSObject

@property(nonatomic,strong) NSString* caseNumber;
@property(nonatomic,strong) NSString* beat;
@property(nonatomic,strong) NSString* minOfUcr;
@property(nonatomic,strong) NSString* location;
@property(nonatomic,strong) NSString* neighborhood;
@property(nonatomic,strong) NSString* maxNumVictims;
@property(nonatomic,strong) NSString* uc2Literal;
@property(nonatomic,strong) NSString* minOfIbrCode;
@property(nonatomic,strong) NSString* occurTime;
@property(nonatomic,strong) NSString* aptOfficeNum;
@property(nonatomic,strong) NSString* locType;
@property(nonatomic,strong) NSString* possTime;
@property(nonatomic,strong) NSString* npu;
@property(nonatomic,strong) NSString* avgDay;
@property(nonatomic,strong) NSString* occurDate;
@property(nonatomic,strong) NSString* aptOfficePrefix;
@property(nonatomic,strong) NSString* dispoCode;
@property(nonatomic,strong) NSString* possDate;
@property(nonatomic,strong) NSString* rptDate;
@property(nonatomic,strong) NSString* offenseId;
@property(nonatomic,strong) NSString* needsRecording;
@property(nonatomic,strong) NSString* longitude;
@property(nonatomic,strong) NSString* latitude;
@property(nonatomic,strong) NSString* humanAddress;
@property(nonatomic,strong) NSString* y;
@property(nonatomic,strong) NSString* shift;
@property(nonatomic,strong) NSString* x;

@end
