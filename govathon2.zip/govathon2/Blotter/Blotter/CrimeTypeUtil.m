//
//  CrimeTypeUtil.m
//  Blotter
//
//  Created by Jeff on 2/23/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import "CrimeTypeUtil.h"

NSString* const kLARCENY = @"LARCENY";
NSString* const kAGG_ASSAULT = @"AGG ASSAULT";
NSString* const kBURGLARY = @"BURGLARY";
NSString* const kAUTO_THEFT = @"AUTO THEFT";
NSString* const kROBBERY = @"ROBBERY";
NSString* const kRAPE = @"RAPE";
NSString* const kHOMICIDE = @"HOMICIDE";

@implementation CrimeTypeUtil

+(NSString*) displayableStringForCrimeTypeString:(NSString*)crimeTypeString
{
    if([crimeTypeString isEqualToString:kLARCENY])
        return @"Larceny";
    else if([crimeTypeString isEqualToString:kAGG_ASSAULT])
        return @"Aggravated Assault";
    else if([crimeTypeString isEqualToString:kBURGLARY])
        return @"Burglary";
    else if([crimeTypeString isEqualToString:kAUTO_THEFT])
        return @"Auto Theft";
    else if([crimeTypeString isEqualToString:kROBBERY])
        return @"Robbery";
    else if([crimeTypeString isEqualToString:kRAPE])
        return @"Rape";
    else if([crimeTypeString isEqualToString:kHOMICIDE])
        return @"Homicide";
    else
        NSLog(@"Unhandled Crime Type=%@",crimeTypeString);
    return nil;
}

@end
