//
//  JSONParser.m
//  Blotter
//
//  Created by Jeff on 2/22/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import "JSONParser.h"
#import "Incident.h"
#import "CrimeTypeUtil.h"

@implementation JSONParser

static JSONParser* instance;

+ (JSONParser*) instance
{
    if(instance == nil) {
        instance = [[JSONParser alloc]init];
        [instance loadJSON];
    }
    return instance;
}

- (void) loadJSON
{
    NSArray* parsedArray = nil;
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"atlanta_crime" ofType:@"json"];
    NSData* jsonData = [NSData dataWithContentsOfFile:filePath];
    NSError** error = nil;
    if(jsonData)
    {
        NSMutableArray *jsonArray = [NSJSONSerialization JSONObjectWithData:jsonData
                                                                    options:kNilOptions
                                                                      error:error];
        parsedArray = [self parseJSONArray:jsonArray];
    }
    else
    {
        NSLog(@"Oh nooooes! There was an Err loading your JSON fool! Err=%@",[*error description]);
    }
    self.loadedIncidents = parsedArray;
}

- (NSArray*) parseJSONArray:(NSMutableArray*)jsonArray
{
    NSMutableArray* incidentArray = [[NSMutableArray alloc]init];
    for(int i=0;i<jsonArray.count;++i)
    {
        NSDictionary* objectDictionary = [jsonArray objectAtIndex:i];
        [incidentArray addObject:[self incidentForObject:objectDictionary]];
    }
    NSLog(@"Our incident array has %i Incidents.",incidentArray.count);
    return incidentArray;
}

- (Incident*) incidentForObject:(NSDictionary*) objectDictionary
{
    Incident* incident = [[Incident alloc]init];
    incident.caseNumber = [objectDictionary objectForKey:@"case_number"];
    incident.beat = [objectDictionary objectForKey:@"beat"];
    incident.minOfUcr = [objectDictionary objectForKey:@"minofucr"];
    incident.location = [objectDictionary objectForKey:@"location"];
    incident.neighborhood = [objectDictionary objectForKey:@"neighborhood"];
    incident.maxNumVictims = [objectDictionary objectForKey:@"maxofnum_victims"];
    incident.uc2Literal = [objectDictionary objectForKey:@"uc2_literal"];
    
    [CrimeTypeUtil displayableStringForCrimeTypeString:incident.uc2Literal];
    
    incident.minOfIbrCode = [objectDictionary objectForKey:@"minofibr_code"];
    
    NSString* occurTime = [objectDictionary objectForKey:@"occur_time"];
    
    NSArray* splitStrings = [occurTime componentsSeparatedByString:@"T"];
    occurTime = [splitStrings objectAtIndex:1];
    
    NSArray* anotherArray = [occurTime componentsSeparatedByString:@":"];
    
    NSDateComponents *comps = [[[NSDateComponents alloc] init] autorelease];
    [comps setHour:[[anotherArray objectAtIndex:0] intValue]];
    [comps setMinute:[[anotherArray objectAtIndex:1] intValue]];
    NSDate* date = [[NSCalendar currentCalendar] dateFromComponents:comps];

    NSDateFormatter* dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    [dateFormatter setDateFormat:@"hh:mm a"];
    occurTime = [dateFormatter stringFromDate:date];
    
    incident.occurTime = occurTime;
    incident.aptOfficeNum = [objectDictionary objectForKey:@"apt_office_num"];
    incident.locType = [objectDictionary objectForKey:@"loc_type"];
    incident.possTime = [objectDictionary objectForKey:@"poss_time"];
    incident.npu = [objectDictionary objectForKey:@"npu"];
    incident.avgDay = [objectDictionary objectForKey:@"avg_day"];
    incident.occurDate = [objectDictionary objectForKey:@"occur_date"];
    incident.aptOfficePrefix = [objectDictionary objectForKey:@"apt_office_prefix"];
    incident.dispoCode = [objectDictionary objectForKey:@"dispo_code"];
    incident.possDate = [objectDictionary objectForKey:@"poss_date"];
    incident.rptDate = [objectDictionary objectForKey:@"rpt_date"];
    incident.offenseId = [objectDictionary objectForKey:@"offense_id"];
    incident.needsRecording = [objectDictionary objectForKey:@"needs_recording"];
    NSDictionary* tmpDic = [objectDictionary objectForKey:@"location_1"];
    incident.longitude = [tmpDic objectForKey:@"longitude"];
    incident.latitude = [tmpDic objectForKey:@"latitude"];
    incident.humanAddress = [objectDictionary objectForKey:@"human_address"];
    incident.x = [objectDictionary objectForKey:@"x"];
    incident.shift = [objectDictionary objectForKey:@"shift"];
    incident.y = [objectDictionary objectForKey:@"y"];
    return incident;
}
@end
