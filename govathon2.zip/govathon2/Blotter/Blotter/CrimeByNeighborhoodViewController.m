//
//  CrimeByNeighborhoodViewController.m
//  Blotter
//
//  Created by Jeff on 2/23/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import "CrimeByNeighborhoodViewController.h"
#import "JSONParser.h"
#import "Incident.h"
#import "CrimeCell.h"
#import "CrimeTypeUtil.h"

@interface CrimeByNeighborhoodViewController ()
@property (retain, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic,retain) UIPickerView* neighborhoodPickerView;
@property (nonatomic,retain) UIBarButtonItem* doneButton;
@property (nonatomic,retain) UIToolbar* toolbar;
@property (nonatomic,retain) NSMutableArray* neighborhoodArray;
@property (nonatomic,retain) NSString* selectedNeighborhood;
@property (nonatomic,retain) NSMutableArray* selectedNeighborhoodIncidentArray;
@property (nonatomic,retain) NSArray* incidents;

@end

@implementation CrimeByNeighborhoodViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = NSLocalizedString(@"Neighborhood", @"Neighorhood");
        self.tabBarItem.image = [UIImage imageNamed:@"marker"];
        self.neighborhoodArray = [[NSMutableArray alloc]init];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    NSLog(@"viewDidLoad");
    JSONParser* jsonParser = [JSONParser instance];
    NSLog(@"JsonParser has %i incidents",jsonParser.loadedIncidents.count);
    self.incidents = jsonParser.loadedIncidents;
    for(int i=0;i<self.incidents.count;++i) {
        Incident* incident = (Incident*)[self.incidents objectAtIndex:i];
        NSString* incidentNeighborhoodString = incident.neighborhood;
        if(![self.neighborhoodArray containsObject:incidentNeighborhoodString])
        {
            [self.neighborhoodArray addObject:incidentNeighborhoodString];
        }
    }
    //alphabetize that long ass list.
    self.neighborhoodArray = [self.neighborhoodArray sortedArrayUsingSelector:
                              @selector(localizedCaseInsensitiveCompare:)];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)neighborhoodButton_onTouchUpInside:(id)sender {
    if(self.toolbar == nil && self.neighborhoodPickerView == nil)
    {
        NSLog(@"Changing Neighb!");
        self.neighborhoodPickerView = [[UIPickerView alloc]init];
        self.neighborhoodPickerView.delegate = self;
        self.neighborhoodPickerView.dataSource = self;
        self.neighborhoodPickerView.showsSelectionIndicator = YES;
        
        float pickerHeight = 180.0f;
        float pickerWidth = self.view.frame.size.width;
        float pickerOriginY = self.view.frame.size.height-pickerHeight-44;
        
        [self.neighborhoodPickerView setFrame:CGRectMake(0.0f,pickerOriginY,pickerWidth,pickerHeight)];
        [self.view addSubview:self.neighborhoodPickerView];
        
        [self addToolBarWithDoneButtonToPickerView:self.neighborhoodPickerView];
        self.toolbar.tintColor = [UIColor blackColor];
    }
}

- (void) addToolBarWithDoneButtonToPickerView:(UIPickerView*)pickerView
{
    self.toolbar = [[UIToolbar alloc]init];
    [self.toolbar sizeToFit];
    self.toolbar.frame = CGRectMake(self.view.frame.origin.x,pickerView.frame.origin.y-self.toolbar.frame.size.height,self.view.frame.size.width,self.toolbar.frame.size.height);
    self.toolbar.translucent = NO;
    
    UIBarButtonItem* doneButton = nil;
    if(pickerView == self.neighborhoodPickerView)
    {
        doneButton = [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(neighborhoodSelected:)];
    }
    UIBarButtonItem *flexibleSpace = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [self.toolbar setItems:[NSArray arrayWithObjects:flexibleSpace,doneButton,nil]];
    [self.view addSubview:self.toolbar];
}

- (void) neighborhoodSelected:(id) sender
{
    self.selectedNeighborhood = [self.neighborhoodArray objectAtIndex:[self.neighborhoodPickerView selectedRowInComponent:0]];
    [self.toolbar removeFromSuperview];
    [self.neighborhoodPickerView removeFromSuperview];
    self.toolbar = nil;
    self.neighborhoodPickerView = nil;
    NSLog(@"selectedNeighborhood:%@",self.selectedNeighborhood);
    
    self.selectedNeighborhoodIncidentArray = [[NSMutableArray alloc]init];
    for(int i=0;i<self.incidents.count;++i)
    {
        Incident* incident = (Incident*)[self.incidents objectAtIndex:i];
        NSString* incidentNeighborhoodString = incident.neighborhood;
        if([self.selectedNeighborhood isEqualToString:incidentNeighborhoodString])
        {
            [self.selectedNeighborhoodIncidentArray addObject:incident];
        }
    }
    NSLog(@"this neighb has %i incidents in it.",self.selectedNeighborhoodIncidentArray.count);
    [self.tableView reloadData];
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

#pragma mark UIPickerViewDataSource

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger) pickerView:(UIPickerView*)thePickerView numberOfRowsInComponent:(NSInteger)component
{
    return self.neighborhoodArray.count;
}

- (NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [self.neighborhoodArray objectAtIndex:row];
}

#pragma mark UIPickerViewDelegate

- (void) pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
}

#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"numberOfRowsInSection:");
    if(self.selectedNeighborhood == nil)
    {
        return 1;
    }
    return self.selectedNeighborhoodIncidentArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"heightForRowAtIndexPath:");
    if(self.selectedNeighborhood == nil)
        return 368;
    return 102;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(self.selectedNeighborhood != nil)
    {
        NSString* CellIdentifier = @"CrimeCell";
        CrimeCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        if (cell == nil) {
            NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"CrimeCell" owner:nil options:nil];
            
            for(id currentObject in topLevelObjects)
            {
                if([currentObject isKindOfClass:[CrimeCell class]])
                {
                    cell = (CrimeCell*)currentObject;
                    break;
                }
            }
        }
        Incident* thisIncident = [self.selectedNeighborhoodIncidentArray objectAtIndex:indexPath.row];
        cell.lblCaseNumber.text = thisIncident.caseNumber;
        cell.lblCrimeType.text = [CrimeTypeUtil displayableStringForCrimeTypeString:thisIncident.uc2Literal];
        cell.lblLocation.text = thisIncident.location;
        cell.lblTime.text = thisIncident.occurTime;
        return cell;
    }
    else {
        UITableViewCell* initialCell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"BasicCell"];
        initialCell.textLabel.text = @"Please Select a Neighborhood";
        initialCell.textLabel.textAlignment = UITextAlignmentCenter;
        initialCell.textLabel.textColor = [UIColor whiteColor];
        return initialCell;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if(self.selectedNeighborhood != nil)
        return [NSString stringWithFormat:@"Crimes In %@",self.selectedNeighborhood];
    else
        return nil;
}

- (void)dealloc {
    [_tableView release];
    [super dealloc];
}
@end
