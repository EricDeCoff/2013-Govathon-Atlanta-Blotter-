//
//  Incident.m
//  Blotter
//
//  Created by Jeff on 2/22/13.
//  Copyright (c) 2013 John McSwain. All rights reserved.
//

#import "Incident.h"

@implementation Incident

@end
