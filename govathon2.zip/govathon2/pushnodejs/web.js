// Built by John McSwain
// @ Govathon 2013 City of Atlanta

var routine = 2;  //1 = simple text (no sound, no payload); 
                  //2 = simple text w/ default sound
 				  //3 = simple text w/ custom sound 1



var isPushNotification = true;
var includeDevice1 = true; //John McSwain iPhone 4
var includeDevice2 = true; //iPad 3
var badge = Math.floor(Math.random() * 10 );
var message = "An incident has been reported in your area";//"Mom's Lifecomm device has been activated. Please call.";//"There are currently "+badge+" reasons why the HTI mobile team is awesome";
var isPayloadPresent = false;
var isSoundPresent = false;
var payload; 
var sound;


switch(routine){
	case 1:
	break;
	
	case 2:
	isSoundPresent = true;
	sound = "siren.wav";
	break;
}


var alertMsg = message;

var certFile = 'certs/Certificates.pem';
var keyFile = 'certs/Certificates.pem';
var pushGateway = 'gateway.sandbox.push.apple.com';
var deviceToken = "aae9583c5190b344d117c12d0670c55e8dce15769bffe7bdfc4679988bc6332e"; 
var deviceToken2 = "724ab27a0646d9fd3806099ede3b438c4d8f8a7795ba745c03c78c5807eb552c"; 



var apns = require('apn');


	console.log("Sending Push Message...");
	var myDevice = new apns.Device(deviceToken);
	var myDevice2 = new apns.Device(deviceToken2);
	var note = new apns.Notification();
	var note2 = new apns.Notification();
			
	var options = {
		        cert: certFile,                 /* Certificate file path */
		        certData: null,                   /* String or Buffer containing certificate data, if supplied uses this instead of cert file path */
		        key:  keyFile,                  /* Key file path */
		        keyData: null,                    /* String or Buffer containing key data, as certData */
		        passphrase: null,                 /* A passphrase for the Key file */
		        ca: null,                         /* String or Buffer of CA data to use for the TLS connection */
		        gateway: pushGateway,/* gateway address */
		        port: 2195,                       /* gateway port */
		        enhanced: true,                   /* enable enhanced format */
		        errorCallback: undefined,         /* Callback when error occurs function(err,notification) */
		        cacheLength: 100                  /* Number of notifications to cache for error purposes */
		    };
		    
	var apnsConnection = new apns.Connection(options);

	if(includeDevice1){
				    note.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
				    note.badge = badge;
				if(isSoundPresent)
				    note.sound = sound; 
				    note.alert = alertMsg;
				if(isPayloadPresent)
				    note.payload = payload;
				    note.device = myDevice;
				    apnsConnection.sendNotification(note);
	}

	if(includeDevice2){
					note2.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
					note2.badge = badge;
					if(isSoundPresent)
					    note2.sound = sound; 
					    note2.alert = alertMsg;
					if(isPayloadPresent)
					    note2.payload = payload;
					    note2.device = myDevice2;
					apnsConnection.sendNotification(note2);
	}
				


	   		
